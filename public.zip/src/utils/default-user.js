const userInfo = {
  login: "",
  token: "",
};

export default userInfo;
