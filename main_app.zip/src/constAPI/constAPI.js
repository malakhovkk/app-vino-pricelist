// export async function getUser() {
//   try {
//     //console.log(defaultUser);

//     return {
//       isOk: defaultUser.token !== "",
//       //isOk: true,
//       data: defaultUser, // window.userInfo,
//     };
//   } catch {
//     return {
//       isOk: false,
//     };
//   }
// }

export const IP = "194.87.239.231:55555";
export const HOST = IP;
export const LOGON = "api/logon";
export const GET_PRICELIST = "api/document";
export const GET_VENDORS = "api/Vendor?have_pricelist=1";
