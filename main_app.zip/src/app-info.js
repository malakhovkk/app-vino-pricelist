const appInfo = {
  title: "ВИНОПАРК",
};
export default appInfo;
